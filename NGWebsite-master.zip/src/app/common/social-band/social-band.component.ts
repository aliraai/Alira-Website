import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-band',
  templateUrl: './social-band.component.html',
  styleUrls: ['./social-band.component.scss']
})
export class SocialBandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
