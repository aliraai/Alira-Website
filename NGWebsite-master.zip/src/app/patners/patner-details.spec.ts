import { PatnerDetails } from './patner-details';

describe('PatnerDetails', () => {
  it('should create an instance', () => {
    expect(new PatnerDetails()).toBeTruthy();
  });
});
