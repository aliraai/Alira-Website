import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatfuel-section',
  templateUrl: './chatfuel-section.component.html',
  styleUrls: ['./chatfuel-section.component.scss']
})
export class ChatfuelSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
