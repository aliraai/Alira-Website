import { ContactDetails } from './contact-details';

describe('ContactDetails', () => {
  it('should create an instance', () => {
    expect(new ContactDetails()).toBeTruthy();
  });
});
